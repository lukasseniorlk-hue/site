const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RequestBody {
  nomeJogo: string;
  console: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { nomeJogo, console: consoleType }: RequestBody = await req.json();

    if (!nomeJogo || !consoleType) {
      return new Response(
        JSON.stringify({ error: "Nome do jogo e console são obrigatórios" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const groqApiKey = "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";

    const prompt = `Você é um especialista em jogos PlayStation e troféus. Forneça informações COMPLETAS sobre o jogo solicitado.

JOGO: "${nomeJogo}" (${consoleType})

IMPORTANTE: Retorne TODOS os troféus do jogo. Não limite a quantidade. Se o jogo tem 50 troféus, mostre os 50. Se tem 30, mostre os 30.

Responda APENAS em JSON válido com esta estrutura:
{
  "nomeJogo": "Nome Oficial Completo do Jogo",
  "descricao": "Descrição detalhada do jogo em 2-3 frases explicando o gênero, gameplay e características principais",
  "historia": "Resumo da história do jogo em 3-4 frases, explicando o contexto, protagonista e objetivo principal",
  "anoLancamento": "ano de lançamento",
  "desenvolvedora": "nome da desenvolvedora",
  "quantidadeTrofeus": número_total_real_de_trofeus,
  "trofeus": [
    {
      "nome": "Nome Exato do Troféu",
      "tipo": "Platina/Ouro/Prata/Bronze",
      "descricao": "Descrição oficial do troféu como aparece no PlayStation",
      "guia": "Guia MUITO detalhado com 4-6 frases explicando: onde conseguir (capítulo/missão específica), como conseguir (passo a passo detalhado), dicas importantes, se é perdível e cuidados necessários",
      "tempoMedio": "tempo realista (ex: 15 minutos, 2 horas, 10-15 horas)",
      "dificuldade": "Muito Fácil/Fácil/Médio/Difícil/Muito Difícil",
      "perdivel": true/false
    }
  ]
}

REGRAS CRÍTICAS:
1. Liste TODOS os troféus do jogo - não omita nenhum
2. Sempre inclua o troféu de Platina primeiro
3. Use informações reais e precisas do jogo "${nomeJogo}"
4. Organize: Platina, depois todos os Ouros, depois Pratas, depois Bronzes
5. Cada guia deve ter no mínimo 4 frases com detalhes específicos
6. Seja extremamente específico em localizações e estratégias`;

    const groqResponse = await fetch(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${groqApiKey}`,
        },
        body: JSON.stringify({
          model: "llama-3.3-70b-versatile",
          messages: [
            {
              role: "system",
              content: "Você é um especialista em jogos PlayStation com conhecimento completo sobre todos os jogos e seus troféus. Sempre forneça informações precisas, completas e detalhadas. Liste TODOS os troféus sem omitir nenhum."
            },
            {
              role: "user",
              content: prompt,
            },
          ],
          temperature: 0.2,
          max_tokens: 16000,
        }),
      }
    );

    if (!groqResponse.ok) {
      throw new Error(`Erro na API Groq: ${groqResponse.statusText}`);
    }

    const groqData = await groqResponse.json();
    const content = groqData.choices[0]?.message?.content;

    if (!content) {
      throw new Error("Resposta vazia da API");
    }

    let resultado;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        resultado = JSON.parse(jsonMatch[0]);
      } else {
        resultado = JSON.parse(content);
      }
    } catch (parseError) {
      console.error("Erro ao fazer parse do JSON:", content);
      throw new Error("Erro ao processar resposta da IA");
    }

    return new Response(JSON.stringify(resultado), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
    });
  } catch (error) {
    console.error("Erro:", error);
    return new Response(
      JSON.stringify({
        error: "Erro ao buscar troféus",
        details: error instanceof Error ? error.message : "Erro desconhecido",
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
