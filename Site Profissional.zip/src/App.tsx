import { useState } from 'react';
import { Search, Trophy, Gamepad2, Clock, Target, Star, Award, AlertCircle, Sparkles } from 'lucide-react';

interface Trophy {
  nome: string;
  tipo?: string;
  descricao?: string;
  guia?: string;
  passoAPasso?: string;
  tempoMedio: string;
  dificuldade: string;
  perdivel?: boolean;
}

interface SearchResult {
  nomeJogo?: string;
  descricao?: string;
  historia?: string;
  anoLancamento?: string;
  desenvolvedora?: string;
  quantidadeTrofeus: number;
  trofeus: Trophy[];
}

function App() {
  const [nomeJogo, setNomeJogo] = useState('');
  const [console, setConsole] = useState('PS5');
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<SearchResult | null>(null);
  const [erro, setErro] = useState('');

  const buscarTrofeus = async () => {
    if (!nomeJogo.trim()) {
      setErro('Por favor, digite o nome de um jogo');
      return;
    }

    setLoading(true);
    setErro('');
    setResultado(null);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/buscar-trofeus`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ nomeJogo, console }),
        }
      );

      if (!response.ok) {
        throw new Error('Erro ao buscar troféus');
      }

      const data = await response.json();
      setResultado(data);
    } catch (error) {
      setErro('Erro ao buscar troféus. Tente novamente.');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const getDificuldadeColor = (dificuldade: string) => {
    const diff = dificuldade.toLowerCase();
    if (diff.includes('muito fácil') || diff.includes('muito facil')) return 'text-emerald-600 bg-emerald-50';
    if (diff.includes('fácil') || diff.includes('facil')) return 'text-green-600 bg-green-50';
    if (diff.includes('médio') || diff.includes('medio')) return 'text-amber-600 bg-amber-50';
    if (diff.includes('muito difícil') || diff.includes('muito dificil')) return 'text-red-700 bg-red-50';
    if (diff.includes('difícil') || diff.includes('dificil')) return 'text-orange-600 bg-orange-50';
    return 'text-gray-600 bg-gray-50';
  };

  const getTipoIcon = (tipo?: string) => {
    if (!tipo) return <Star className="w-5 h-5" />;
    const t = tipo.toLowerCase();
    if (t.includes('platina')) return <Sparkles className="w-5 h-5 text-cyan-400" />;
    if (t.includes('ouro')) return <Award className="w-5 h-5 text-yellow-500" />;
    if (t.includes('prata')) return <Trophy className="w-5 h-5 text-gray-400" />;
    return <Star className="w-5 h-5 text-amber-600" />;
  };

  const getTipoBg = (tipo?: string) => {
    if (!tipo) return 'from-blue-500 to-blue-600';
    const t = tipo.toLowerCase();
    if (t.includes('platina')) return 'from-cyan-400 via-blue-500 to-purple-600';
    if (t.includes('ouro')) return 'from-yellow-400 to-yellow-600';
    if (t.includes('prata')) return 'from-gray-300 to-gray-500';
    return 'from-amber-500 to-amber-700';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-40"></div>

      <div className="container mx-auto px-4 py-12 max-w-7xl relative z-10">
        <div className="text-center mb-16 animate-fade-in">
          <div className="flex items-center justify-center mb-6 relative">
            <div className="absolute inset-0 blur-3xl bg-yellow-400/20 animate-pulse"></div>
            <Trophy className="w-20 h-20 text-yellow-400 relative z-10 drop-shadow-2xl animate-float" strokeWidth={1.5} />
          </div>
          <h1 className="text-6xl md:text-7xl font-black text-white mb-4 tracking-tight">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 via-blue-400 to-cyan-400 animate-gradient">
              Trophy Hunter
            </span>
          </h1>
          <p className="text-blue-200 text-xl md:text-2xl font-light max-w-2xl mx-auto">
            Guias completos e detalhados para conquistar todos os troféus do PlayStation
          </p>
        </div>

        <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl p-8 md:p-10 mb-10 border border-white/20 animate-slide-up">
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="md:col-span-2">
              <label className="block text-gray-800 font-bold mb-3 text-sm uppercase tracking-wide">
                Nome do Jogo
              </label>
              <div className="relative group">
                <input
                  type="text"
                  value={nomeJogo}
                  onChange={(e) => setNomeJogo(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && buscarTrofeus()}
                  placeholder="Ex: The Last of Us, God of War, Elden Ring..."
                  className="w-full px-5 py-4 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all text-gray-800 placeholder-gray-400 group-hover:border-gray-400"
                />
                <Gamepad2 className="absolute right-4 top-4 text-gray-400 w-6 h-6 group-hover:text-blue-500 transition-colors" />
              </div>
            </div>

            <div>
              <label className="block text-gray-800 font-bold mb-3 text-sm uppercase tracking-wide">
                Console
              </label>
              <select
                value={console}
                onChange={(e) => setConsole(e.target.value)}
                className="w-full px-5 py-4 border-2 border-gray-300 rounded-xl focus:outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all bg-white text-gray-800 hover:border-gray-400 cursor-pointer"
              >
                <option value="PS3">PlayStation 3</option>
                <option value="PS4">PlayStation 4</option>
                <option value="PS5">PlayStation 5</option>
              </select>
            </div>
          </div>

          <button
            onClick={buscarTrofeus}
            disabled={loading}
            className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 disabled:from-gray-400 disabled:to-gray-500 text-white font-bold py-5 px-8 rounded-xl transition-all flex items-center justify-center gap-3 shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] disabled:hover:scale-100 group"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-6 w-6 border-3 border-white border-t-transparent"></div>
                <span className="text-lg">Buscando troféus...</span>
              </>
            ) : (
              <>
                <Search className="w-6 h-6 group-hover:rotate-12 transition-transform" />
                <span className="text-lg">Buscar Troféus</span>
              </>
            )}
          </button>

          {erro && (
            <div className="mt-6 p-5 bg-red-50 border-l-4 border-red-500 text-red-700 rounded-lg animate-shake flex items-start gap-3">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span className="font-medium">{erro}</span>
            </div>
          )}
        </div>

        {resultado && (
          <div className="space-y-8 animate-fade-in-up">
            <div className="bg-gradient-to-br from-white/95 to-blue-50/90 backdrop-blur-xl rounded-3xl shadow-2xl p-8 md:p-12 border border-white/30">
              <div className="flex items-start gap-6 mb-6">
                <div className="flex-shrink-0">
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center shadow-xl">
                    <Gamepad2 className="w-10 h-10 text-white" />
                  </div>
                </div>
                <div className="flex-grow">
                  <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-2">
                    {resultado.nomeJogo || 'Resultados da Busca'}
                  </h2>
                  {resultado.desenvolvedora && resultado.anoLancamento && (
                    <p className="text-gray-600 text-lg font-medium">
                      {resultado.desenvolvedora} • {resultado.anoLancamento}
                    </p>
                  )}
                </div>
              </div>

              {resultado.descricao && (
                <div className="bg-white/80 rounded-2xl p-6 mb-6 border-l-4 border-blue-500">
                  <h3 className="font-bold text-gray-900 text-xl mb-3 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-blue-600" />
                    Sobre o Jogo
                  </h3>
                  <p className="text-gray-700 text-lg leading-relaxed">{resultado.descricao}</p>
                </div>
              )}

              {resultado.historia && (
                <div className="bg-white/80 rounded-2xl p-6 mb-6 border-l-4 border-cyan-500">
                  <h3 className="font-bold text-gray-900 text-xl mb-3 flex items-center gap-2">
                    <Star className="w-5 h-5 text-cyan-600" />
                    História
                  </h3>
                  <p className="text-gray-700 text-lg leading-relaxed">{resultado.historia}</p>
                </div>
              )}

              <div className="bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl p-6 text-white shadow-lg">
                <div className="flex items-center justify-center gap-4">
                  <Trophy className="w-10 h-10" />
                  <div className="text-center">
                    <p className="text-5xl font-black mb-1">{resultado.quantidadeTrofeus}</p>
                    <p className="text-xl font-bold opacity-90">Troféus Disponíveis</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl p-8 md:p-10 border border-white/20">
              <h3 className="text-3xl font-black text-gray-900 mb-8 flex items-center gap-3">
                <Award className="w-8 h-8 text-yellow-500" />
                Lista Completa de Troféus
              </h3>

              <div className="space-y-6">
                {resultado.trofeus.map((trofeu, index) => (
                  <div
                    key={index}
                    className="group bg-gradient-to-br from-gray-50 to-blue-50/50 rounded-2xl p-6 md:p-8 border-l-4 border-blue-500 hover:border-blue-600 hover:shadow-2xl transition-all duration-300 hover:scale-[1.01] animate-fade-in-up"
                    style={{ animationDelay: `${index * 30}ms` }}
                  >
                    <div className="flex items-start gap-5">
                      <div className="flex-shrink-0">
                        <div className={`w-14 h-14 bg-gradient-to-br ${getTipoBg(trofeu.tipo)} rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg group-hover:scale-110 transition-transform`}>
                          {getTipoIcon(trofeu.tipo)}
                        </div>
                      </div>

                      <div className="flex-grow space-y-4">
                        <div>
                          <div className="flex items-start justify-between gap-4 mb-2">
                            <h4 className="text-2xl md:text-3xl font-bold text-gray-900 group-hover:text-blue-700 transition-colors">
                              {trofeu.nome}
                            </h4>
                            {trofeu.tipo && (
                              <span className={`px-4 py-1.5 rounded-full text-sm font-bold ${
                                trofeu.tipo.toLowerCase().includes('platina') ? 'bg-gradient-to-r from-cyan-400 to-cyan-600 text-white' :
                                trofeu.tipo.toLowerCase().includes('ouro') ? 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-white' :
                                trofeu.tipo.toLowerCase().includes('prata') ? 'bg-gradient-to-r from-gray-300 to-gray-500 text-white' :
                                'bg-gradient-to-r from-amber-500 to-amber-700 text-white'
                              } shadow-md whitespace-nowrap`}>
                                {trofeu.tipo}
                              </span>
                            )}
                          </div>
                          {trofeu.descricao && (
                            <p className="text-gray-600 italic text-lg">{trofeu.descricao}</p>
                          )}
                        </div>

                        <div className="flex flex-wrap gap-3">
                          <div className="flex items-center gap-2 bg-white rounded-lg px-4 py-2 shadow-sm">
                            <Clock className="w-5 h-5 text-blue-600" />
                            <span className="text-gray-700">
                              <span className="font-bold">Tempo:</span> {trofeu.tempoMedio}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 bg-white rounded-lg px-4 py-2 shadow-sm">
                            <Target className="w-5 h-5 text-blue-600" />
                            <span className={`font-bold px-3 py-1 rounded-md ${getDificuldadeColor(trofeu.dificuldade)}`}>
                              {trofeu.dificuldade}
                            </span>
                          </div>
                          {trofeu.perdivel && (
                            <div className="flex items-center gap-2 bg-red-50 rounded-lg px-4 py-2 shadow-sm border border-red-200">
                              <AlertCircle className="w-5 h-5 text-red-600" />
                              <span className="text-red-700 font-bold">PERDÍVEL</span>
                            </div>
                          )}
                        </div>

                        <div className="bg-white rounded-xl p-6 border-2 border-gray-200 shadow-sm hover:border-blue-300 transition-colors">
                          <h5 className="font-bold text-gray-900 mb-3 text-lg flex items-center gap-2">
                            <Award className="w-5 h-5 text-blue-600" />
                            Guia Completo:
                          </h5>
                          <p className="text-gray-700 leading-relaxed whitespace-pre-line text-base">
                            {trofeu.guia || trofeu.passoAPasso}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;